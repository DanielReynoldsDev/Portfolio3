        <!-- Javascript -->
        <script src="js/script.js">               
        </script>
        <!-- /Javascript -->