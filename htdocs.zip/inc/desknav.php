                <!-- Desktop Nav -->
                <nav>
                <div id="nav-content"> 
                        <a href="/" class="nav-initial">
                            <div class="hexagon"><h2 class="letters">D.R</h2></div>
                        </a>
                        <ul id="nav-list">
                            <li><a href="about.php">About Me</a></li>
                            <li><a href="index.php#portfolio" class="portfolio-nav">My Portfolio</a></li>
                            <li><a href="coding_examples.php">Coding Examples</a></li>
                            <li><a href="scs_scheme.php">SCS Scheme</a></li>
                            <li><a href="index.php#contact" class="contact-nav">Contact Me</a></li>
                        </ul>
                        <ul id="nav-social" style="padding-left: 0px;">
                            <li><a href="https://www.linkedin.com/in/daniel-reynolds-941875235/" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                            <li><a href="https://github.com/DanielReynoldsDev/" target="_blank"><i class="fab fa-github-square"></i></a></li>
                        </ul>
                </div>
                </nav>
                <!-- /Desktop Nav -->