                    <!-- Hero Image -->
                    <header id="header-home">

                        <div id="banner">
                            <span id="greetings"></span>
                            <span id="greetingsname"></span>
                            <span id="banner-tagline"></span>
                        </div>
                        <div id="scroll-down">
                            <a href="#portfolio">
                                <i class="fas fa-angle-down"></i>
                                <br>
                                Scroll Down</a>
                        </div>
                    </header>
                    <!-- /Hero Image -->