# JavaScript-Array-Reflection
Assigning an image to an email using JavaScript
